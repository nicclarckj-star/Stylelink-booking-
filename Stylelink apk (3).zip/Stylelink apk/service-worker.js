self.addEventListener("install", () => {
  console.log("StyleLink installed");
});